import numpy as np

# This was just useful to have around so i could test various things without running the whole shebang.
