"""Probability review laboratory assignment."""
